//
//  MainView.swift
//  C2
//
//  Created by Enoch on 4/15/25.
//

import SwiftUI
import SwiftData

struct MainView: View {
    @Binding var isLoggedIn: Bool

    @Environment(\.modelContext) private var modelContext
    
    @Relationship(deleteRule: .cascade, inverse: \AssignedQuestion.mentor)
    var assignedQuestions: [AssignedQuestion]

    @Query private var mentors: [Mentor]
    @Query private var questions: [Question]
    
    @State private var selectedMentor: Mentor?
    @State private var selectedQuestion: Question?
    
    
    var body: some View {
        ZStack {
            C2App.BGColor
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                HStack {
                    Spacer()
                    Button(action: {
                        // 로그아웃 처리
                        isLoggedIn = false
                    }) {
                        Text("로그아웃")
                            .foregroundColor(.red)
                    }
                    .padding()
                }
                
                Spacer()
                
                if let mentor = selectedMentor {
                    Text("🎯 \(mentor.name)")
                        .font(.title2)
                        .foregroundColor(.black)
                    Text("📘 \(mentor.field)")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    
                    if !mentor.assignedQuestions.isEmpty {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("🗂 받은 질문 목록:")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                            ForEach(mentor.assignedQuestions, id: \.id) { q in
                                Text("- \(q.content)")
                                    .font(.footnote)
                                    .foregroundColor(.black)
                            }
                        }
                        .padding(.top, 10)
                    }
                }
                
                if let question = selectedQuestion {
                                    Text("❓ \(question.content)")
                                        .font(.headline)
                                        .foregroundColor(.black)
                                        .padding(.top)
                                }

                
                NavigationLink("보관함으로 이동") {
                    ArchiveView()
                }
                
                NavigationLink("상세 페이지로 이동") {
                    DetailView(itemTitle: "예시 아이템")
                }
        
                
                Button("뽑기") {
                    guard let mentor = mentors.randomElement() else { return }
                    
                    // 멘토가 받은 질문 목록 가져오기
                    let assignedContents = Set(mentor.assignedQuestions.map { $0.content })
                    
                    // 아직 안 받은 질문만 필터링
                    let unassignedQuestions = questions.filter { !assignedContents.contains($0.content) }
                    
                    // 모든 질문을 받았을 경우 처리
                    guard let question = unassignedQuestions.randomElement() else {
                        selectedMentor = mentor
                        selectedQuestion = nil
                        print("⚠️ 이 멘토는 더 이상 받을 질문이 없습니다.")
                        return
                    }
                    
                    // 질문 할당 및 저장
                    let newAssigned = AssignedQuestion(content: question.content, mentor: mentor)
                    modelContext.insert(newAssigned)
                    
                    do {
                        try modelContext.save()
                        print("✅ 질문 '\(question.content)'이 멘토 '\(mentor.name)'에게 할당됨")
                    } catch {
                        print("❌ 저장 실패: \(error)")
                    }

                    // 상태 업데이트
                    selectedMentor = mentor
                    selectedQuestion = question
                }
                .font(.title2)
                
                
                Spacer()
            }
            .navigationTitle("메인")
        }
    }
    
}
