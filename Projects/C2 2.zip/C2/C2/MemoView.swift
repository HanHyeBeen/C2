//
//  MemoView.swift
//  C2
//
//  Created by Enoch on 4/21/25.
//

import SwiftUI
import SwiftData

struct MemoView: View {
    var question: Question
    var isEditing: Bool
    @Binding var memoText: String

    var onStartEdit: () -> Void
    var onEndEdit: () -> Void
    var onDelete: () -> Void

    @Environment(\.modelContext) private var modelContext

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Text("\(question.question.content)")
                    .font(.body)

                Spacer()

                if question.memo != nil {
                    Button {
                        onStartEdit()
                    } label: {
                        Image(systemName: "pencil")
                            .foregroundColor(.orange)
                    }

                    Button {
                        onDelete()
                    } label: {
                        Image(systemName: "trash")
                            .foregroundColor(.red)
                    }

                } else {
                    Button {
                        if isEditing {
                            onEndEdit()
                        } else {
                            onStartEdit()
                        }
                    } label: {
                        Image(systemName: "plus.circle")
                            .foregroundColor(.blue)
                    }
                }
            }

            if isEditing {
                VStack(alignment: .leading) {
                    TextField("메모를 입력하세요", text: $memoText)
                        .textFieldStyle(.roundedBorder)

                    Button("저장") {
                        question.memo = memoText
                        question.dateMemoAdded = Date()
                        try? modelContext.save()
                        onEndEdit()
                    }
                    .font(.caption)
                    .padding(.top, 4)
                }
            }

            if let memo = question.memo {
                Text("📝 메모: \(memo)")
                    .font(.footnote)
                    .foregroundColor(.gray)
            }
        }
        .padding()
        .background(Color.white.opacity(0.9))
        .cornerRadius(8)
        .shadow(radius: 1)
    }
}
