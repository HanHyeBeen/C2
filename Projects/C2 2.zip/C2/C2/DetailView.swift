//
//  DetailView.swift
//  C2
//
//  Created by Enoch on 4/15/25.
//

import SwiftUI
import SwiftData

struct DetailView: View {
    let mentor: Mentor?
    let learner: Learner?
    let questions: [Question]
    let itemTitle: String
    let itemExplain: String

    @Environment(\.modelContext) private var modelContext
    @State private var editingMemoID: UUID?
    @State private var memoText: String = ""
    @State private var showingDeleteAlertID: UUID?

    var body: some View {
        ZStack {
            C2App.BGColor
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    ForEach(questions, id: \.id) { aq in
                        MemoView(
                            question: aq,
                            isEditing: editingMemoID == aq.id,
                            memoText: $memoText,
                            onStartEdit: {
                                editingMemoID = aq.id
                                memoText = aq.memo ?? ""
                            },
                            onEndEdit: {
                                editingMemoID = nil
                            },
                            onDelete: {
                                showingDeleteAlertID = aq.id
                            }
                        )
                        .alert("메모를 삭제하시겠습니까?", isPresented: Binding(
                            get: { showingDeleteAlertID == aq.id },
                            set: { if !$0 { showingDeleteAlertID = nil } }
                        )) {
                            Button("삭제", role: .destructive) {
                                aq.memo = nil
                                aq.dateMemoAdded = nil
                                try? modelContext.save()
                                showingDeleteAlertID = nil
                            }
                            Button("취소", role: .cancel) {
                                showingDeleteAlertID = nil
                            }
                        }
                    }

                    Spacer()
                }
                .padding()
            }
            .navigationTitle(itemTitle + "(" + itemExplain + ")")
        }
    }
}
